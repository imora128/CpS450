int x = 5, y = 10;
int z;

int main()
{
  z = x < y;

}
