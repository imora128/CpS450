g++ -gstabs -fno-rtti -c -Wa,-ahln,-L objdemo.cpp > objdemo.s.list

