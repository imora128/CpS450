#include <stdio.h>

int x, y;

int main()
{
  int quebec = 10;
  int awk = 9;
  int hmmm = 8;

  x = 5;
  y = 10;

  printf("%d %d\n", x, quebec);
}
