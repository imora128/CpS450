gcc -g -c  stdlib.c
gcc teststdlib.c stdlib.o -oteststdlib

