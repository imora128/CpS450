#include <stdio.h>

int main()
{
  int x = sub(5, 3);
  writeint(0);
  writeint(x);
  
}
